
import { Link, useLocation } from "react-router-dom";
import { useIsMobile } from "@/hooks/use-mobile";
import { NotificationsDropdown } from "@/components/notifications/NotificationsDropdown";
import { useNotifications } from "@/components/notifications/NotificationProvider";

export const DesktopNavigation = () => {
  const isMobile = useIsMobile();
  const location = useLocation();
  const { notifications, unreadCount, markAsRead, markAllAsRead } = useNotifications();
  
  if (isMobile) return null;
  
  const isActive = location.pathname;
  const isSimRacingActive = isActive.startsWith('/sim-racing');
  
  return (
    <div className="hidden items-center space-x-4 min-[768px]:flex">
      <Link to="/" className={`nav-link ${isActive === '/' ? 'text-sm-red' : ''} hover:text-sm-red`}>
        Home
      </Link>
      {/* <Link to="/social" className="nav-link">
        Social
      </Link>
      <Link to="/shop" className="nav-link">
        Shop
      </Link>
      <Link to="/vehicles" className="nav-link">
        Vehicles
      </Link> */}
      <Link to="/events" className={`nav-link ${isActive === '/events' ? 'text-sm-red' : ''} hover:text-sm-red`}>
        MotorSports & Events
      </Link>
      <Link to="/sim-racing" className={`nav-link ${isSimRacingActive ? 'text-sm-red' : ''} hover:text-sm-red`}>
        SR
      </Link>
      <Link to="/about" className={`nav-link ${isActive === '/about' ? 'text-sm-red' : ''} hover:text-sm-red`}>
        About
      </Link>
      {/* <Link to="/services" className={`nav-link ${isActive === '/services' ? 'text-sm-600' : ''} hover:text-red-600`}>
        Services
      </Link> */}
      {/* <Link to="/moto-revolution" className={`nav-link ${isActive === '/moto-revolution' ? 'text-red-600' : ''} hover:text-red-600`}>
          <span className="text-nowrap"> Moto Revolution</span>
      </Link> */}
      {/* <NotificationsDropdown
        notifications={notifications}
        unreadCount={unreadCount}
        onMarkAsRead={markAsRead}
        onMarkAllAsRead={markAllAsRead}
      /> */}
    </div>
  );
};
