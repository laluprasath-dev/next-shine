
import { useToast as useToastOriginal, toast as toastOriginal } from "@/hooks/use-toast";

export const useToast = useToastOriginal;
export const toast = toastOriginal;
